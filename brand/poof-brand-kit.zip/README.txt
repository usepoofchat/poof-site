Poof brand kit
usepoof.chat/docs/brandbook/

Colors
  Rust    #e8661f   primary accent
  Burnt   #9c3b14   rust for text on light grounds
  Ink     #1d1f2b   text, dark surfaces
  Stone   #a7a49b   quiet details
  Cream   #fbf7ef   light surfaces
  Frost   #9db4ff   quantum / future topics only
  Light ground #e8e9e4   Dark ground #16171f

Type
  Geist (headlines and body), Geist Mono (labels, system and crypto details).
  The wordmark is drawn, not typed. Never set "Poof" in a font as a logo.

Use the files as they are: no recoloring, stretching, rotating or effects.
Questions: contact@usepoof.chat
